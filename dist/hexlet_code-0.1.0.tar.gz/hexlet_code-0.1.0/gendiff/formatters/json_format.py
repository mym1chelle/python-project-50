import json


def json_format(diff):
    return json.dumps(diff, indent=2)
