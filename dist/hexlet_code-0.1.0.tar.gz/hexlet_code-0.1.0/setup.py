# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.formatters', 'gendiff.gendiff_func', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['pyyaml>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/mym1chelle/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/mym1chelle/python-project-50/actions)\n\n### My test and linter status:\n[![.github/workflows/gendiff-check.yml](https://github.com/mym1chelle/python-project-50/actions/workflows/gendiff-check.yml/badge.svg)](https://github.com/mym1chelle/python-project-50/actions/workflows/gendiff-check.yml)\n\n### Maintainability:\n<a href="https://codeclimate.com/github/mym1chelle/python-project-50/maintainability"><img src="https://api.codeclimate.com/v1/badges/b474dc64cfea8f6ecdd8/maintainability" /></a>\n\n### Test Coverage Badge:\n<a href="https://codeclimate.com/github/mym1chelle/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/b474dc64cfea8f6ecdd8/test_coverage" /></a>\n\n### ASCIINEMA REC:\n<a href=\'https://asciinema.org/a/5z7pxcFQF2nNJDxwBzLTGYn2H\'>Step three: demonstration of the package and the ability to import the function</a>  \n<a href=\'https://asciinema.org/a/KVJUoSVA2AIBM56cgyi4vCj3P\'>Step five: demonstration of work with YAML files</a>  \n<a href=\'https://asciinema.org/a/kEKWldJdo2UUgnGtD6Uq8qadV\'>Step six: find differences in two files and create a formatter to output their fifferences</a>  \n',
    'author': 'mym1chelle',
    'author_email': 'timur.a.samusenko@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
