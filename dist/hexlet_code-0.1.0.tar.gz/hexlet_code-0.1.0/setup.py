# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.gendiff_func', 'gendiff.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/mym1chelle/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/mym1chelle/python-project-50/actions)',
    'author': 'mym1chelle',
    'author_email': 'timur.a.samusenko@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
